# 🌐 Aplicación Flutter - Consulta de Pokémon

Esta aplicación fue desarrollada con **Flutter y Dart** para demostrar cómo obtener datos desde Internet mediante una petición **HTTP** utilizando la librería `http`.

## 📋 Descripción

La app realiza una consulta HTTP a la [PokeAPI](https://pokeapi.co/) para mostrar información básica de un Pokémon, como su nombre, tipo e imagen oficial.  
El ejemplo muestra los datos del Pokémon **Pikachu**.

## 🛠️ Tecnologías utilizadas

- Flutter SDK  
- Lenguaje Dart  
- Paquete `http` (para consumo de APIs REST)  
- API pública [PokeAPI](https://pokeapi.co/)

## ⚙️ Instalación y ejecución

1. Clonar el repositorio:
   ```bash
   git clone https://github.com/TU_USUARIO/pokeapi_flutter_app.git
   ```
2. Entrar en la carpeta del proyecto:
   ```bash
   cd pokeapi_flutter_app
   ```
3. Instalar dependencias:
   ```bash
   flutter pub get
   ```
4. Ejecutar la aplicación:
   ```bash
   flutter run
   ```

## 👨‍💻 Autor

**Raymundo Salas Rodríguez**  
Proyecto académico – Flutter y consumo de APIs REST.

## 📚 Referencias

- Flutter. (2024). *Fetching data from the internet*. Recuperado de [https://docs.flutter.dev/cookbook/networking/fetch-data](https://docs.flutter.dev/cookbook/networking/fetch-data)  
- Dart.dev. (2024). *Package http*. Recuperado de [https://pub.dev/packages/http](https://pub.dev/packages/http)  
- PokeAPI. (2024). *Pokémon RESTful API*. Recuperado de [https://pokeapi.co/](https://pokeapi.co/)
